$(function(){
	if(!isLogin()){
        window.location.href = "/index/index/login";
    }
})