<?php
namespace app\sdlcadmin\model;

use think\Model;

class Website extends Model{


}
